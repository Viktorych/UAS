Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/) and this project adheres to [Semantic Versioning](http://semver.org/).

1.0.4
-----

Bugfix add support for zxing qrcodes

1.0.0
-----

### Changed

-	Update api to return result and bounding box : https://github.com/edi9999/jsqrcode/issues/35
-	Update api to be error-first ([#30](https://github.com/edi9999/jsqrcode/pull/30)\)

0.x
---

-	Initial release

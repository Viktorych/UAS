This page illustrates my [article about interaction between HTML and SVG](http://habrahabr.ru/post/127994/).

__[See in action](http://envek.github.io/Amestris)__.
